---
name: demo-skill
description: 用于测试的演示 skill
---

# Demo
Hello skill body.
